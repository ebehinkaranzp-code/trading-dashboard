#!/usr/bin/env python3
"""Download monthly Binance Vision kline ZIPs for BTCUSDT."""
import argparse
import calendar
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "metadata" / "manifest.json"

def month_iter(start, end):
    sy, sm = map(int, start.split("-"))
    ey, em = map(int, end.split("-"))
    y, m = sy, sm
    while (y, m) <= (ey, em):
        yield f"{y}-{m:02d}"
        m += 1
        if m == 13:
            y, m = y + 1, 1

def last_complete_month():
    now = datetime.now(timezone.utc)
    y, m = now.year, now.month - 1
    if m == 0:
        y, m = y - 1, 12
    return f"{y}-{m:02d}"

def load_manifest():
    if MANIFEST.exists():
        try:
            return json.loads(MANIFEST.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"source": "Binance Public Data", "updated_utc": None, "files": []}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--market", choices=["spot", "futures"], default="spot")
    ap.add_argument("--symbol", default="BTCUSDT")
    ap.add_argument("--interval", default="1m")
    ap.add_argument("--start", default="2017-08")
    ap.add_argument("--end", default="latest")
    ap.add_argument("--sleep", type=float, default=0.15)
    args = ap.parse_args()

    end = last_complete_month() if args.end == "latest" else args.end
    base_url = ("https://data.binance.vision/data/spot/monthly/klines"
                if args.market == "spot" else
                "https://data.binance.vision/data/futures/um/monthly/klines")
    out_dir = ROOT / "data" / args.market / "klines" / args.interval
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest = load_manifest()
    known = {(x.get("market"), x.get("symbol"), x.get("interval"), x.get("month")): x
             for x in manifest.get("files", [])}

    for month in month_iter(args.start, end):
        filename = f"{args.symbol}-{args.interval}-{month}.zip"
        dest = out_dir / filename
        key = (args.market, args.symbol, args.interval, month)
        if dest.exists() and dest.stat().st_size > 0:
            print(f"SKIP exists: {filename}")
            continue
        url = f"{base_url}/{args.symbol}/{args.interval}/{filename}"
        req = Request(url, headers={"User-Agent": "TradingDashboard-HistoricalArchive/1.0"})
        try:
            with urlopen(req, timeout=60) as response:
                content = response.read()
            if not content.startswith(b"PK"):
                raise ValueError("Response is not a ZIP archive")
            dest.write_bytes(content)
            entry = {
                "market": args.market, "symbol": args.symbol,
                "interval": args.interval, "month": month,
                "file": str(dest.relative_to(ROOT)).replace("\\", "/"),
                "bytes": len(content), "source_url": url,
                "downloaded_utc": datetime.now(timezone.utc).isoformat()
            }
            known[key] = entry
            print(f"OK {filename} ({len(content):,} bytes)")
        except HTTPError as e:
            if e.code == 404:
                print(f"NOT FOUND (month may predate listing): {filename}")
            else:
                print(f"HTTP ERROR {e.code}: {url}")
        except (URLError, TimeoutError, ValueError, OSError) as e:
            print(f"ERROR {filename}: {e}")
        time.sleep(args.sleep)

    manifest["files"] = sorted(known.values(),
        key=lambda x: (x["market"], x["symbol"], x["interval"], x["month"]))
    manifest["updated_utc"] = datetime.now(timezone.utc).isoformat()
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Manifest updated: {MANIFEST}")

if __name__ == "__main__":
    main()
